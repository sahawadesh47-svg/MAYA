package com.maya.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class MayaAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    companion object {
        var instance: MayaAccessibilityService? = null
        fun home() = instance?.performGlobalAction(GLOBAL_ACTION_HOME) ?: false
        fun back() = instance?.performGlobalAction(GLOBAL_ACTION_BACK) ?: false
        fun recents() = instance?.performGlobalAction(GLOBAL_ACTION_RECENTS) ?: false
    }
}
