package com.maya.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MayaAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    // ---------------- helpers ----------------

    private fun allRoots(): List<AccessibilityNodeInfo> {
        val list = mutableListOf<AccessibilityNodeInfo>()
        try { windows?.forEach { w -> w.root?.let { list.add(it) } } } catch (e: Exception) {}
        rootInActiveWindow?.let { list.add(it) }
        return list
    }

    private fun labelOf(n: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        n.text?.let { sb.append(it).append(' ') }
        n.contentDescription?.let { sb.append(it).append(' ') }
        if (Build.VERSION.SDK_INT >= 30) n.stateDescription?.let { sb.append(it) }
        return sb.toString().lowercase()
    }

    private fun forEachNode(root: AccessibilityNodeInfo, f: (AccessibilityNodeInfo) -> Boolean) {
        val q = java.util.LinkedList<AccessibilityNodeInfo>()
        q.add(root)
        while (q.isNotEmpty()) {
            val n = q.poll() ?: break
            if (f(n)) return
            for (i in 0 until n.childCount) n.getChild(i)?.let { q.add(it) }
        }
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        while (x != null) {
            if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            x = x.parent
        }
        return false
    }

    // ---------------- WhatsApp send ----------------

    private fun trySend(attempt: Int, done: (Boolean) -> Unit) {
        val node = findSend()
        if (node != null) { done(clickNode(node)); return }
        if (attempt >= 12) { done(false); return }
        handler.postDelayed({ trySend(attempt + 1, done) }, 1000)
    }

    private fun findSend(): AccessibilityNodeInfo? {
        for (root in allRoots()) {
            for (id in listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
                root.findAccessibilityNodeInfosByViewId(id).firstOrNull()?.let { return it }
            }
            var found: AccessibilityNodeInfo? = null
            forEachNode(root) { n ->
                val d = n.contentDescription?.toString()?.lowercase()
                if (d == "send" || d == "भेजें") { found = n; true } else false
            }
            if (found != null) return found
        }
        return null
    }

    // ---------------- Quick Settings toggles ----------------

    private fun stateOf(node: AccessibilityNodeInfo): Boolean? {
        var x: AccessibilityNodeInfo? = node
        repeat(4) {
            val n = x ?: return null
            if (n.isCheckable) return n.isChecked
            val parts = mutableListOf<String>()
            if (Build.VERSION.SDK_INT >= 30) n.stateDescription?.let { parts.add(it.toString()) }
            n.contentDescription?.let { parts.add(it.toString()) }
            for (p in parts) {
                val tokens = p.lowercase().split(Regex("[^a-z]+"))
                if ("off" in tokens) return false
                if ("on" in tokens) return true
            }
            x = n.parent
        }
        return null
    }

    private fun findByLabels(labels: List<String>): Pair<AccessibilityNodeInfo, String>? {
        val roots = allRoots()
        for (label in labels) for (r in roots) {
            var found: AccessibilityNodeInfo? = null
            forEachNode(r) { n ->
                if (labelOf(n).contains(label)) { found = n; true } else false
            }
            found?.let { return Pair(it, label) }
        }
        return null
    }

    private fun swipeLeft() {
        val dm = resources.displayMetrics
        val path = Path().apply {
            moveTo(dm.widthPixels * 0.85f, dm.heightPixels * 0.22f)
            lineTo(dm.widthPixels * 0.15f, dm.heightPixels * 0.22f)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 250)).build()
        dispatchGesture(g, null, null)
    }

    private fun closePanel(delay: Long = 800) {
        handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK) }, delay)
    }

    private fun quickToggle(labels: List<String>, want: Boolean?, stage2: String?,
                            fallback: Intent?, done: (String) -> Unit) {
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        attemptTile(0, labels, want, stage2, fallback, done)
    }

    private fun attemptTile(attempt: Int, labels: List<String>, want: Boolean?, stage2: String?,
                            fallback: Intent?, done: (String) -> Unit) {
        handler.postDelayed({
            val f = findByLabels(labels)
            if (f != null) { onTileFound(f.first, want, stage2, done); return@postDelayed }
            if (attempt == 3) swipeLeft()
            if (attempt >= 7) {
                performGlobalAction(GLOBAL_ACTION_BACK)
                fallback?.let {
                    try { it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(it) } catch (e: Exception) {}
                }
                done("fallback")
                return@postDelayed
            }
            attemptTile(attempt + 1, labels, want, stage2, fallback, done)
        }, if (attempt == 0) 1300L else 700L)
    }

    private fun onTileFound(node: AccessibilityNodeInfo, want: Boolean?, stage2: String?, done: (String) -> Unit) {
        if (stage2 != null && labelOf(node).contains("internet")) {
            // Android 12+ me "Internet" tile ek panel kholta hai
            clickNode(node)
            handler.postDelayed({ stage2Toggle(0, stage2, want, done) }, 1300)
            return
        }
        val cur = stateOf(node)
        if (want != null && cur == want) { closePanel(500); done("already"); return }
        clickNode(node)
        closePanel()
        done("ok")
    }

    private fun findSwitchNear(root: AccessibilityNodeInfo, label: String): AccessibilityNodeInfo? {
        var result: AccessibilityNodeInfo? = null
        forEachNode(root) { n ->
            if (labelOf(n).contains(label)) {
                var x: AccessibilityNodeInfo? = n
                var level = 0
                while (x != null && level < 4 && result == null) {
                    forEachNode(x) { c -> if (c.isCheckable) { result = c; true } else false }
                    x = x.parent
                    level++
                }
                result != null
            } else false
        }
        return result
    }

    private fun stage2Toggle(attempt: Int, label: String, want: Boolean?, done: (String) -> Unit) {
        var sw: AccessibilityNodeInfo? = null
        for (r in allRoots()) { sw = findSwitchNear(r, label); if (sw != null) break }
        if (sw == null) {
            if (attempt < 5) { handler.postDelayed({ stage2Toggle(attempt + 1, label, want, done) }, 700); return }
            performGlobalAction(GLOBAL_ACTION_BACK)
            done("fallback")
            return
        }
        val cur = if (sw.isCheckable) sw.isChecked else null
        if (want == null || cur == null || cur != want) clickNode(sw)
        closePanel(900)
        done("ok")
    }

    private fun swipeVertical(down: Boolean) {
        val dm = resources.displayMetrics
        val x = dm.widthPixels * 0.5f
        val a = dm.heightPixels * 0.70f
        val b = dm.heightPixels * 0.30f
        val path = Path().apply { if (down) { moveTo(x, a); lineTo(x, b) } else { moveTo(x, b); lineTo(x, a) } }
        dispatchGesture(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 300)).build(), null, null)
    }

    // ---------------- Generic: tap, type, youtube ----------------

    private fun doClickText(text: String): Boolean {
        val q = text.lowercase().trim()
        if (q.isBlank()) return false
        var best: AccessibilityNodeInfo? = null
        for (r in allRoots()) forEachNode(r) { n ->
            val l = labelOf(n).trim()
            if (l == q) { best = n; true }
            else { if (best == null && l.contains(q)) best = n; false }
        }
        val b = best ?: return false
        return clickNode(b)
    }

    private fun doType(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        var target: AccessibilityNodeInfo? = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (target == null) forEachNode(root) { n -> if (n.isEditable) { target = n; true } else false }
        val t = target ?: return false
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return t.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun tryYoutube(attempt: Int, done: (Boolean) -> Unit) {
        for (root in allRoots()) {
            var f: AccessibilityNodeInfo? = null
            forEachNode(root) { n ->
                val d = n.contentDescription?.toString()?.lowercase()
                if (d != null && d.contains("play video")) { f = n; true } else false
            }
            val node = f
            if (node != null) { done(clickNode(node)); return }
        }
        if (attempt >= 10) { done(false); return }
        handler.postDelayed({ tryYoutube(attempt + 1, done) }, 1000)
    }

    // ---------------- public API ----------------

    companion object {
        var instance: MayaAccessibilityService? = null
        fun home() = instance?.performGlobalAction(GLOBAL_ACTION_HOME) ?: false
        fun back() = instance?.performGlobalAction(GLOBAL_ACTION_BACK) ?: false
        fun recents() = instance?.performGlobalAction(GLOBAL_ACTION_RECENTS) ?: false
        fun notifications() = instance?.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) ?: false
        fun screenshot() = instance?.performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT) ?: false
        fun lockScreen() = instance?.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) ?: false
        fun scroll(down: Boolean) { instance?.swipeVertical(down) }
        fun clickText(text: String): Boolean = instance?.doClickText(text) ?: false
        fun typeText(text: String): Boolean = instance?.doType(text) ?: false
        fun clickFirstVideo(done: (Boolean) -> Unit) {
            val s = instance
            if (s == null) done(false) else s.tryYoutube(0, done)
        }
        fun clickSend(done: (Boolean) -> Unit) {
            val s = instance
            if (s == null) done(false) else s.trySend(0, done)
        }
        fun quickToggle(labels: List<String>, want: Boolean?, stage2: String?,
                        fallback: Intent?, done: (String) -> Unit) {
            val s = instance
            if (s == null) done("noaccess") else s.quickToggle(labels, want, stage2, fallback, done)
        }
    }
}
