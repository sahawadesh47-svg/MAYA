package com.maya.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var anime: AnimeView
    private lateinit var startBtn: TextView
    private lateinit var statusTv: TextView
    private lateinit var panel: View
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pending: String? = null
    private val handler = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun sysDim(name: String): Int {
        val id = resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun roundBg(c1: Int, c2: Int, radius: Int) =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2)).apply {
            cornerRadius = dp(radius).toFloat()
        }

    private fun pill(label: String, c1: Int, c2: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = resources.getFont(R.font.poppins_medium)
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(13), dp(22), dp(13))
            background = roundBg(c1, c2, 30)
            setOnClickListener { onClick() }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        val sb = sysDim("status_bar_height")
        val nb = sysDim("navigation_bar_height")

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.rgb(10, 6, 20))

        anime = AnimeView(this)
        anime.onSpeak = { say(it) }
        root.addView(anime, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // ---- top: title ----
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, sb + dp(10), 0, 0)
        }
        val title = TextView(this).apply {
            text = "Maya"
            textSize = 46f
            typeface = resources.getFont(R.font.poppins_bold)
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setShadowLayer(24f, 0f, 4f, Color.argb(190, 255, 80, 170))
        }
        title.post {
            val w = title.paint.measureText("Maya")
            title.paint.shader = LinearGradient(0f, 0f, w, 0f,
                intArrayOf(Color.rgb(255, 154, 213), Color.WHITE, Color.rgb(199, 155, 255)),
                null, Shader.TileMode.CLAMP)
            title.invalidate()
        }
        val sub = TextView(this).apply {
            text = "TUMHARI  VOICE  ASSISTANT"
            textSize = 11f
            letterSpacing = 0.25f
            typeface = resources.getFont(R.font.poppins_light)
            setTextColor(Color.argb(220, 255, 255, 255))
            gravity = Gravity.CENTER
        }
        statusTv = TextView(this).apply {
            textSize = 12f
            typeface = resources.getFont(R.font.poppins_medium)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(6), dp(16), dp(6))
            background = GradientDrawable().apply {
                setColor(Color.argb(120, 0, 0, 0)); cornerRadius = dp(20).toFloat()
            }
        }
        top.addView(title)
        top.addView(sub)
        top.addView(statusTv, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(8)
        })
        root.addView(top, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        // ---- setup panel ----
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = GradientDrawable().apply {
                setColor(Color.argb(238, 22, 12, 40)); cornerRadius = dp(22).toFloat()
            }
        }
        list.addView(TextView(this).apply {
            text = "Pehli baar ye sab ek-ek karke ON karo"
            setTextColor(Color.argb(230, 255, 255, 255))
            textSize = 13f
            typeface = resources.getFont(R.font.poppins_medium)
        })
        val dark = Color.argb(255, 52, 34, 86)
        val steps = listOf<Pair<String, () -> Unit>>(
            "1 · Mic, Contacts, Call permission" to {
                val perms = mutableListOf(Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
                if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
                requestPermissions(perms.toTypedArray(), 1)
            },
            "2 · Display over other apps" to {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            },
            "3 · Accessibility ON karo (Maya)" to {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            },
            "4 · Battery optimization OFF" to {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            },
            "5 · Brightness permission" to {
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
            }
        )
        for ((label, act) in steps) {
            list.addView(pill(label, dark, dark, act), LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(8)
            })
        }
        val scroll = ScrollView(this).apply { addView(list); visibility = View.GONE }
        panel = scroll
        root.addView(scroll, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            (resources.displayMetrics.heightPixels * 0.5f).toInt(), Gravity.BOTTOM).apply {
            leftMargin = dp(16); rightMargin = dp(16); bottomMargin = nb + dp(96)
        })

        // ---- bottom buttons ----
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(8), dp(16), nb + dp(22))
        }
        val setupBtn = pill("⚙  Setup", Color.argb(190, 40, 24, 70), Color.argb(190, 40, 24, 70)) {
            panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        startBtn = pill("▶  START MAYA", Color.rgb(255, 95, 162), Color.rgb(142, 91, 255)) { toggleMaya() }
        bottom.addView(setupBtn, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        bottom.addView(startBtn, LinearLayout.LayoutParams(
            0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(12) })
        root.addView(bottom, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        setContentView(root)
        tts = TextToSpeech(this, this)
        refresh()
    }

    private fun toggleMaya() {
        if (MayaBus.running) {
            stopService(Intent(this, MayaService::class.java))
            MayaBus.running = false
        } else {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Pehle Setup me Mic permission do", Toast.LENGTH_LONG).show()
                panel.visibility = View.VISIBLE
                return
            }
            startForegroundService(Intent(this, MayaService::class.java))
        }
        refresh()
    }

    private fun refresh() {
        startBtn.text = if (MayaBus.running) "■  STOP MAYA" else "▶  START MAYA"
        statusTv.text = if (MayaBus.running) "●  Sun rahi hai · bolo \"Maya\"" else "●  So rahi hai · START dabao"
        statusTv.setTextColor(if (MayaBus.running) Color.rgb(124, 255, 178) else Color.rgb(255, 179, 199))
        handler.postDelayed({ refresh() }, 700)
    }

    // ---- Maya ki awaaz (screen reactions ke liye) ----
    override fun onInit(status: Int) {
        val t = tts ?: return
        val r = t.setLanguage(Locale("hi", "IN"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            t.setLanguage(Locale("en", "IN"))
        }
        t.setPitch(1.3f)
        t.setSpeechRate(1.0f)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { MayaBus.activitySpeaking = true }
            override fun onDone(id: String?) { MayaBus.activitySpeaking = false }
            override fun onError(id: String?) { MayaBus.activitySpeaking = false }
        })
        ttsReady = true
        pending?.let { say(it) }
        pending = null
    }

    private fun say(text: String) {
        if (MayaBus.speaking) return
        if (!ttsReady) { pending = text; return }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ui")
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        tts?.shutdown()
        super.onDestroy()
    }
}
