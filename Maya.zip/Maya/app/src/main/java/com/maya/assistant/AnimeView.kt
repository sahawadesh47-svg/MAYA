package com.maya.assistant

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*
import kotlin.random.Random

/** Maya anime character: poora code se bana hua, har hissa animated. */
class AnimeView(ctx: Context) : View(ctx) {

    var onSpeak: ((String) -> Unit)? = null

    private val bg: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.bg)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val bubbleFont: Typeface = resources.getFont(R.font.poppins_medium)
    private val rect = RectF()
    private val rnd = Random(System.nanoTime())

    private val R_NONE = 0
    private val R_HEAD = 1
    private val R_CHEEK = 2
    private val R_BODY = 3
    private val R_ARMR = 4
    private val R_ARML = 5
    private val R_LEGS = 6
    private val R_WAKE = 7
    private val R_INTRO = 8

    // colors
    private val skin = Color.rgb(255, 227, 214)
    private val skinShade = Color.rgb(238, 198, 183)
    private val orange = Color.rgb(255, 122, 60)
    private val blouse = Color.rgb(252, 250, 255)
    private val skirtC = Color.rgb(38, 40, 66)
    private val tights = Color.rgb(44, 44, 60)
    private val ink = Color.rgb(58, 28, 78)

    private val backHairShader = LinearGradient(0f, 120f, 0f, 1150f,
        Color.rgb(255, 150, 200), Color.rgb(140, 80, 210), Shader.TileMode.CLAMP)
    private val frontHairShader = LinearGradient(0f, 30f, 0f, 700f,
        Color.rgb(255, 170, 212), Color.rgb(200, 110, 215), Shader.TileMode.CLAMP)
    private val irisShader = RadialGradient(0f, 0f, 50f,
        Color.rgb(170, 245, 255), Color.rgb(90, 70, 210), Shader.TileMode.CLAMP)
    private var overlayShader: Shader? = null

    // time & state
    private var lastNs = System.nanoTime()
    private var time = 0f
    private var blinkAt = 2f
    private var blinkP = -1f
    private var openF = 1f
    private var lookX = 0f
    private var lookY = 0f
    private var tgtX = 0f
    private var tgtY = 0f
    private var nextLook = 1.5f
    private var touching = false
    private var mouth = 0f
    private var happy = 0f
    private var blush = 0.3f
    private var surprise = 0f
    private var waveR = 0f
    private var waveL = 0f
    private var wiggle = 0f
    private var tiltX = 0f
    private var react = R_NONE
    private var reactT = 0f
    private var lastSpeakAt = -10f
    private var lastWake = MayaBus.wakeCount
    private var introDone = false
    private var lookXe = 0f
    private var lookYe = 0f

    // draw-time values
    private var sway = 0f
    private var breath = 0f
    private var jumpY = 0f
    private var sc = 1f
    private var ox = 0f
    private var oy = 0f

    private class Fx(var x: Float, var y: Float, var vx: Float, var vy: Float,
                     var life: Float, val maxLife: Float, val size: Float, val type: Int)
    private val fx = ArrayList<Fx>()

    private class Bokeh(val x: Float, var y: Float, val r: Float, val sp: Float,
                        val ph: Float, val a: Int, val col: Int)
    private val bokeh = ArrayList<Bokeh>()

    private var shownUntil = 0L
    private var bubbleAt = 0f

    private val headLines = arrayOf("Aww janu, aur karo na", "Hehe, sir pe haath mat rakho", "Mujhe pyaar aa raha hai")
    private val cheekLines = arrayOf("Oye janu! Sharam aa rahi hai", "Kya kar rahe ho janu?", "Gaal kheench rahe ho?")
    private val bodyLines = arrayOf("Gudgudi ho rahi hai janu!", "Hihi, ruko na", "Arre arre, kya kar rahe ho")
    private val armRLines = arrayOf("Hi janu!", "Hello hello!", "Bye bye janu!")
    private val armLLines = arrayOf("Haath pakad liya mera?", "Aaj bade pyaar se dekh rahe ho")
    private val legLines = arrayOf("Arre, kya kar rahe ho!", "Hehe, upar ghumo na")

    init {
        for (i in 0 until 24) {
            val colors = intArrayOf(Color.WHITE, Color.rgb(255, 170, 220), Color.rgb(150, 230, 255))
            bokeh.add(Bokeh(rnd.nextFloat(), rnd.nextFloat(), 0.006f + rnd.nextFloat() * 0.016f,
                0.01f + rnd.nextFloat() * 0.03f, rnd.nextFloat() * 6.28f,
                30 + rnd.nextInt(60), colors[rnd.nextInt(3)]))
        }
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
    private fun easeOutBack(x: Float): Float {
        val c1 = 1.70158f
        val c3 = c1 + 1f
        val d = x - 1f
        return 1f + c3 * d * d * d + c1 * d * d
    }
    private fun fill(color: Int) { p.shader = null; p.style = Paint.Style.FILL; p.color = color }
    private fun stroke(color: Int, w: Float) {
        p.shader = null; p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        p.color = color; p.strokeWidth = w
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        overlayShader = LinearGradient(0f, 0f, 0f, h.toFloat(),
            intArrayOf(Color.argb(215, 10, 5, 25), Color.argb(110, 20, 8, 45),
                Color.argb(140, 16, 6, 38), Color.argb(235, 8, 4, 20)),
            floatArrayOf(0f, 0.35f, 0.7f, 1f), Shader.TileMode.CLAMP)
    }

    // ---------------- reactions ----------------

    private fun trigger(r: Int, text: String?) {
        react = r
        reactT = 0f
        if (r == R_HEAD || r == R_WAKE || r == R_INTRO) spawnHearts(if (r == R_HEAD) 7 else 4)
        if (r == R_INTRO) spawnStars(16)
        if (text != null) {
            MayaBus.setBubble(text, 3200)
            if (time - lastSpeakAt > 1.4f) { lastSpeakAt = time; onSpeak?.invoke(text) }
        }
    }

    private fun spawnHearts(n: Int) {
        repeat(n) {
            fx.add(Fx(-90f + rnd.nextFloat() * 180f, 180f + rnd.nextFloat() * 120f,
                -30f + rnd.nextFloat() * 60f, -(90f + rnd.nextFloat() * 70f),
                1.6f + rnd.nextFloat() * 0.8f, 2.4f, 14f + rnd.nextFloat() * 14f, 0))
        }
    }

    private fun spawnStars(n: Int) {
        repeat(n) {
            fx.add(Fx(-320f + rnd.nextFloat() * 640f, 100f + rnd.nextFloat() * 800f,
                -10f + rnd.nextFloat() * 20f, -(15f + rnd.nextFloat() * 40f),
                1.2f + rnd.nextFloat() * 0.9f, 2.1f, 14f + rnd.nextFloat() * 18f, 1))
        }
    }

    private fun hit(x: Float, y: Float) {
        val lx = (x - width / 2f) / sc
        val ly = (y - oy) / sc
        when {
            ly in 10f..330f && abs(lx) < 215f -> trigger(R_HEAD, headLines.random())
            ly in 330f..610f && abs(lx) < 180f -> trigger(R_CHEEK, cheekLines.random())
            ly in 640f..1060f && lx > 160f && lx < 430f -> trigger(R_ARMR, armRLines.random())
            ly in 640f..1060f && lx < -160f && lx > -430f -> trigger(R_ARML, armLLines.random())
            ly in 640f..1320f && abs(lx) < 270f -> trigger(R_BODY, bodyLines.random())
            ly > 1320f && abs(lx) < 300f -> trigger(R_LEGS, legLines.random())
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { touching = true; look(e.x, e.y); hit(e.x, e.y) }
            MotionEvent.ACTION_MOVE -> look(e.x, e.y)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> touching = false
        }
        return true
    }

    private fun look(x: Float, y: Float) {
        tgtX = ((x - width / 2f) / (width / 2f)).coerceIn(-1f, 1f)
        tgtY = ((y - (oy + 385f * sc)) / (height / 3f)).coerceIn(-1f, 1f)
    }

    // ---------------- update ----------------

    private fun update(dt: Float) {
        time += dt
        if (!introDone && time > 0.6f) { introDone = true; trigger(R_INTRO, "Namaste janu! Kaise ho?") }
        if (MayaBus.wakeCount != lastWake) { lastWake = MayaBus.wakeCount; trigger(R_WAKE, null) }
        if (react != R_NONE) { reactT += dt; if (reactT > 2.2f) react = R_NONE }

        val speaking = MayaBus.speaking || MayaBus.activitySpeaking
        val hT = when (react) { R_HEAD, R_ARMR, R_ARML, R_WAKE, R_INTRO -> 1f; else -> 0f }
        val bT = when (react) { R_HEAD, R_CHEEK, R_BODY -> 1f; R_NONE -> 0.3f; else -> 0.6f }
        val sT = when (react) { R_CHEEK -> 0.5f; R_BODY -> 0.6f; R_LEGS -> 0.9f; R_WAKE -> 0.6f; else -> 0f }
        val wRT = if (react == R_ARMR || react == R_WAKE || react == R_INTRO) 1f else 0f
        val wLT = if (react == R_ARML) 1f else 0f
        val wgT = when (react) { R_BODY -> 1f; R_LEGS -> 0.5f; else -> 0f }
        val tiltT = when (react) { R_HEAD -> 8f; R_CHEEK -> -6f; R_WAKE -> 4f; else -> 0f }

        val k = 1f - exp(-dt * 7f)
        happy += (hT - happy) * k
        blush += (bT - blush) * k
        surprise += (sT - surprise) * k
        waveR += (wRT - waveR) * k
        waveL += (wLT - waveL) * k
        wiggle += (wgT - wiggle) * k
        tiltX += (tiltT - tiltX) * k

        val mT = if (speaking)
            0.25f + 0.75f * abs(sin(time * 12f)) * (0.6f + 0.4f * abs(sin(time * 4.1f)))
        else surprise * 0.4f
        mouth += (mT - mouth) * (1f - exp(-dt * 18f))

        // blink
        blinkAt -= dt
        if (blinkP < 0f && blinkAt <= 0f) blinkP = 0f
        if (blinkP >= 0f) {
            blinkP += dt / 0.2f
            if (blinkP >= 1f) {
                blinkP = -1f
                blinkAt = 2.2f + rnd.nextFloat() * 3.5f
                if (rnd.nextFloat() < 0.2f) blinkAt = 0.15f
            }
        }
        openF = if (blinkP < 0f) 1f else (1f - sin(blinkP * Math.PI.toFloat())).coerceAtLeast(0.05f)

        // eyes look
        if (!touching) {
            nextLook -= dt
            if (nextLook <= 0f) {
                tgtX = rnd.nextFloat() * 2f - 1f
                tgtY = (rnd.nextFloat() * 2f - 1f) * 0.6f
                nextLook = 1.5f + rnd.nextFloat() * 2.5f
                if (rnd.nextFloat() < 0.4f) { tgtX = 0f; tgtY = 0f }
            }
        }
        val ex = if (react == R_CHEEK) 0.9f else tgtX
        val ey = if (react == R_CHEEK) 0.5f else tgtY
        val kl = 1f - exp(-dt * 6f)
        lookX += (ex - lookX) * kl
        lookY += (ey - lookY) * kl
        lookXe = lookX
        lookYe = lookY

        // fx
        for (i in fx.indices.reversed()) {
            val f = fx[i]
            f.x += f.vx * dt; f.y += f.vy * dt; f.life -= dt
            if (f.life <= 0f) fx.removeAt(i)
        }
        for (b in bokeh) { b.y -= b.sp * dt; if (b.y < -0.05f) b.y = 1.05f }
    }

    // ---------------- main draw ----------------

    override fun onDraw(c: Canvas) {
        val ns = System.nanoTime()
        val dt = ((ns - lastNs) / 1e9f).coerceIn(0f, 0.05f)
        lastNs = ns
        update(dt)

        val w = width.toFloat()
        val h = height.toFloat()
        sc = min(w / 860f, h * 0.66f / 1600f)
        ox = w / 2f
        oy = h * 0.22f

        drawBg(c, w, h)
        drawBokeh(c, w, h)

        // aura
        val pulse = 1f + 0.04f * sin(time * 1.5f)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(w / 2f, oy + 520f * sc, 430f * sc * pulse,
            Color.argb(80, 255, 120, 210), Color.argb(0, 255, 120, 210), Shader.TileMode.CLAMP)
        c.drawCircle(w / 2f, oy + 520f * sc, 430f * sc * pulse, p)
        p.shader = null

        val introP = (time / 1.3f).coerceIn(0f, 1f)
        val e = easeOutBack(introP).coerceAtLeast(0.01f)
        val alpha = (introP * 1.6f).coerceIn(0f, 1f)
        val layer = if (alpha < 1f) c.saveLayerAlpha(0f, 0f, w, h, (255 * alpha).toInt()) else c.save()
        c.translate(ox, oy)
        c.scale(sc * e, sc * e, 0f, 1600f)
        drawCharacter(c)
        drawFx(c)
        c.restoreToCount(layer)

        drawBubble(c, w)
        postInvalidateOnAnimation()
    }

    private fun drawBg(c: Canvas, w: Float, h: Float) {
        val zoom = 1.08f + 0.02f * sin(time * 0.25f)
        val panX = sin(time * 0.18f) * w * 0.02f
        val s = max(w / bg.width, h / bg.height) * zoom
        val bw = bg.width * s
        val bh = bg.height * s
        rect.set((w - bw) / 2f + panX, (h - bh) / 2f, (w - bw) / 2f + panX + bw, (h - bh) / 2f + bh)
        p.shader = null; p.style = Paint.Style.FILL; p.color = Color.WHITE
        c.drawBitmap(bg, null, rect, p)
        p.shader = overlayShader
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
    }

    private fun drawBokeh(c: Canvas, w: Float, h: Float) {
        for (b in bokeh) {
            val x = (b.x + 0.02f * sin(time * 0.6f + b.ph)) * w
            fill(Color.argb(b.a, Color.red(b.col), Color.green(b.col), Color.blue(b.col)))
            c.drawCircle(x, b.y * h, b.r * w, p)
        }
    }

    // ---------------- character ----------------

    private fun drawCharacter(c: Canvas) {
        breath = sin(time * 1.7f)
        sway = sin(time * 1.1f) + 0.5f * sin(time * 2.3f) + wiggle * sin(time * 14f) * 1.3f
        jumpY = if (react == R_BODY || react == R_LEGS || react == R_WAKE)
            -abs(sin(reactT * 9f)) * 34f * max(0f, 1f - reactT / 1.6f) else 0f

        fill(Color.argb(90, 0, 0, 0))
        rect.set(-240f, 1565f, 240f, 1625f)
        c.drawOval(rect, p)

        c.save()
        c.translate(0f, jumpY)
        drawBackHair(c)
        drawNeck(c)
        drawLegs(c)
        drawSkirt(c)
        drawTorso(c)
        drawArms(c)
        drawHead(c)
        c.restore()
    }

    private fun drawBackHair(c: Canvas) {
        val sx = sway * 26f
        path.reset()
        path.moveTo(-205f, 230f)
        path.cubicTo(-315f, 520f, -310f, 860f, -250f + sx * 0.4f, 1050f)
        path.quadTo(-185f + sx, 1150f, -105f + sx, 1085f)
        path.quadTo(-35f + sx, 1160f, 40f + sx, 1090f)
        path.quadTo(125f + sx, 1150f, 195f + sx, 1085f)
        path.quadTo(262f + sx * 0.6f, 1060f, 255f + sx * 0.4f, 1020f)
        path.cubicTo(312f, 860f, 318f, 520f, 205f, 230f)
        path.close()
        p.shader = backHairShader; p.style = Paint.Style.FILL; p.color = Color.WHITE
        c.drawPath(path, p)
        p.shader = null
    }

    private fun drawNeck(c: Canvas) {
        fill(skinShade)
        rect.set(-40f, 520f, 40f, 670f)
        c.drawRoundRect(rect, 22f, 22f, p)
    }

    private fun drawLegs(c: Canvas) {
        fill(tights)
        rect.set(-118f, 1280f, -36f, 1535f); c.drawRoundRect(rect, 30f, 30f, p)
        rect.set(36f, 1280f, 118f, 1535f); c.drawRoundRect(rect, 30f, 30f, p)
        fill(Color.rgb(250, 248, 255))
        rect.set(-142f, 1520f, -22f, 1592f); c.drawRoundRect(rect, 32f, 32f, p)
        rect.set(22f, 1520f, 142f, 1592f); c.drawRoundRect(rect, 32f, 32f, p)
        fill(orange)
        rect.set(-142f, 1560f, -22f, 1572f); c.drawRect(rect, p)
        rect.set(22f, 1560f, 142f, 1572f); c.drawRect(rect, p)
    }

    private fun drawSkirt(c: Canvas) {
        val sk = sway * 12f
        path.reset()
        path.moveTo(-114f, 945f)
        path.lineTo(114f, 945f)
        path.quadTo(222f + sk, 1100f, 248f + sk, 1300f)
        path.lineTo(-248f + sk, 1300f)
        path.quadTo(-222f + sk, 1100f, -114f, 945f)
        path.close()
        fill(skirtC); c.drawPath(path, p)
        stroke(Color.argb(60, 255, 255, 255), 3f)
        for (i in -2..2) {
            c.drawLine(i * 40f, 965f, i * 95f + sk, 1290f, p)
        }
        stroke(orange, 13f)
        c.drawLine(-246f + sk, 1288f, 246f + sk, 1288f, p)
    }

    private fun drawTorso(c: Canvas) {
        c.save()
        c.scale(1f, 1f + 0.014f * breath, 0f, 960f)
        path.reset()
        path.moveTo(-62f, 650f); path.lineTo(-152f, 685f)
        path.quadTo(-184f, 785f, -138f, 862f); path.lineTo(-114f, 962f)
        path.lineTo(114f, 962f); path.lineTo(138f, 862f)
        path.quadTo(184f, 785f, 152f, 685f); path.lineTo(62f, 650f)
        path.close()
        fill(blouse); c.drawPath(path, p)
        stroke(Color.argb(40, 120, 100, 160), 6f)
        c.drawLine(-120f, 780f, -104f, 950f, p)
        c.drawLine(120f, 780f, 104f, 950f, p)
        fill(orange)
        rect.set(-118f, 938f, 118f, 968f); c.drawRoundRect(rect, 10f, 10f, p)
        path.reset()
        path.moveTo(-50f, 648f); path.lineTo(50f, 648f); path.lineTo(0f, 735f); path.close()
        fill(skin); c.drawPath(path, p)
        stroke(Color.argb(120, 150, 130, 170), 5f)
        c.drawLine(-50f, 648f, 0f, 735f, p)
        c.drawLine(50f, 648f, 0f, 735f, p)
        drawBow(c, 0f, 738f, 1f)
        c.restore()
    }

    private fun drawBow(c: Canvas, x: Float, y: Float, s: Float) {
        val w = sway * 6f
        fill(orange)
        path.reset()
        path.moveTo(x, y); path.quadTo(x - 80f * s, y - 52f * s + w, x - 92f * s, y + 6f * s)
        path.quadTo(x - 70f * s, y + 50f * s, x, y); path.close()
        c.drawPath(path, p)
        path.reset()
        path.moveTo(x, y); path.quadTo(x + 80f * s, y - 52f * s + w, x + 92f * s, y + 6f * s)
        path.quadTo(x + 70f * s, y + 50f * s, x, y); path.close()
        c.drawPath(path, p)
        path.reset()
        path.moveTo(x - 6f * s, y + 8f * s); path.lineTo(x - 36f * s, y + 78f * s + w)
        path.lineTo(x - 8f * s, y + 62f * s); path.close()
        c.drawPath(path, p)
        path.reset()
        path.moveTo(x + 6f * s, y + 8f * s); path.lineTo(x + 36f * s, y + 78f * s + w)
        path.lineTo(x + 8f * s, y + 62f * s); path.close()
        c.drawPath(path, p)
        fill(Color.rgb(230, 90, 40))
        c.drawCircle(x, y, 16f * s, p)
    }

    private fun drawArms(c: Canvas) {
        val flap = wiggle * 6f * sin(time * 14f)
        val shL = lerp(8f, 112f, waveL) - breath * 1.2f + flap
        val elL = lerp(-6f, 72f + 24f * sin(time * 10f), waveL)
        val shR = lerp(-8f, -112f, waveR) + breath * 1.2f - flap
        val elR = lerp(6f, -72f + 24f * sin(time * 10f), waveR)
        drawArm(c, -1f, shL, elL)
        drawArm(c, 1f, shR, elR)
    }

    private fun drawArm(c: Canvas, side: Float, shoulder: Float, elbow: Float) {
        c.save()
        c.translate(side * 150f, 702f)
        c.rotate(shoulder)
        stroke(blouse, 58f)
        c.drawLine(0f, 0f, 0f, 150f, p)
        stroke(Color.argb(35, 120, 100, 160), 4f)
        c.drawLine(-26f, 20f, -26f, 140f, p)
        c.translate(0f, 150f)
        c.rotate(elbow)
        stroke(skin, 44f)
        c.drawLine(0f, 0f, 0f, 140f, p)
        fill(skin)
        c.drawCircle(0f, 162f, 34f, p)
        c.restore()
    }

    // ---------------- head ----------------

    private fun drawEye(c: Canvas, cx: Float, cy: Float, side: Float, open: Float) {
        if (happy > 0.55f) {
            path.reset()
            path.moveTo(cx - 50f, cy + 16f)
            path.quadTo(cx, cy - 52f, cx + 50f, cy + 16f)
            stroke(ink, 12f); c.drawPath(path, p)
            return
        }
        c.save()
        c.scale(1f, max(open, 0.07f), cx, cy)
        fill(Color.WHITE)
        rect.set(cx - 54f, cy - 64f, cx + 54f, cy + 64f)
        c.drawOval(rect, p)
        path.reset(); path.addOval(rect, Path.Direction.CW)
        c.save()
        c.clipPath(path)
        c.save()
        c.translate(cx + lookXe * 15f, cy + lookYe * 12f + 8f)
        p.shader = irisShader; p.style = Paint.Style.FILL; p.color = Color.WHITE
        c.drawCircle(0f, 0f, 50f, p)
        p.shader = null
        fill(Color.rgb(40, 20, 70)); c.drawCircle(0f, 4f, 24f, p)
        fill(Color.WHITE); c.drawCircle(-17f, -20f, 14f, p)
        p.color = Color.argb(220, 255, 255, 255); c.drawCircle(18f, 18f, 7f, p)
        c.restore()
        c.restore()
        path.reset()
        path.moveTo(cx - 58f, cy - 6f)
        path.cubicTo(cx - 52f, cy - 82f, cx + 52f, cy - 82f, cx + 58f, cy - 6f)
        stroke(ink, 12f); c.drawPath(path, p)
        stroke(ink, 9f)
        c.drawLine(cx + side * 56f, cy - 12f, cx + side * 76f, cy - 32f, p)
        c.restore()
    }

    private fun drawHead(c: Canvas) {
        val tilt = 3f * sin(time * 0.8f) + tiltX
        val bob = 4f * sin(time * 1.7f)
        c.save()
        c.translate(0f, bob)
        c.rotate(tilt, 0f, 570f)

        // face
        path.reset()
        path.moveTo(-168f, 300f)
        path.cubicTo(-168f, 170f, -100f, 110f, 0f, 110f)
        path.cubicTo(100f, 110f, 168f, 170f, 168f, 300f)
        path.cubicTo(168f, 420f, 95f, 545f, 0f, 575f)
        path.cubicTo(-95f, 545f, -168f, 420f, -168f, 300f)
        path.close()
        fill(skin); c.drawPath(path, p)
        stroke(Color.argb(110, 200, 140, 150), 4f); c.drawPath(path, p)

        // blush
        val ba = (50 + 150 * blush).toInt().coerceIn(0, 220)
        fill(Color.argb(ba, 255, 105, 145))
        rect.set(-150f, 440f, -76f, 480f); c.drawOval(rect, p)
        rect.set(76f, 440f, 150f, 480f); c.drawOval(rect, p)

        // eyes
        drawEye(c, -90f, 385f, -1f, openF)
        drawEye(c, 90f, 385f, 1f, openF)

        // brows
        val raise = surprise * 18f + happy * 8f
        stroke(Color.argb(230, 130, 55, 150), 9f)
        for (sx in floatArrayOf(-1f, 1f)) {
            val cx = sx * 90f
            path.reset()
            path.moveTo(cx - 46f, 316f - raise * 0.3f)
            path.quadTo(cx, 296f - raise, cx + 46f, 316f - raise * 0.3f)
            c.drawPath(path, p)
        }

        // nose
        stroke(Color.argb(160, 210, 140, 130), 5f)
        path.reset(); path.moveTo(-5f, 458f); path.quadTo(0f, 465f, 5f, 458f)
        c.drawPath(path, p)

        // mouth
        if (mouth > 0.12f) {
            val ry = 6f + mouth * 34f
            val rx = 24f + mouth * 10f
            fill(Color.rgb(150, 40, 75))
            rect.set(-rx, 498f - ry * 0.25f, rx, 498f + ry * 1.5f)
            c.drawOval(rect, p)
            fill(Color.rgb(255, 135, 160))
            rect.set(-rx * 0.6f, 498f + ry * 0.7f, rx * 0.6f, 498f + ry * 1.45f)
            c.drawOval(rect, p)
        } else {
            stroke(Color.rgb(205, 85, 110), 7f)
            path.reset()
            path.moveTo(-34f, 500f)
            path.quadTo(0f, 520f + happy * 14f, 34f, 500f)
            c.drawPath(path, p)
        }

        // front hair
        val bs = sway * 8f
        path.reset()
        path.moveTo(-192f, 330f)
        path.cubicTo(-208f, 100f, -88f, 30f, 0f, 30f)
        path.cubicTo(88f, 30f, 208f, 100f, 192f, 330f)
        val tx = floatArrayOf(160f, 92f, 26f, -42f, -108f, -166f)
        val ty = floatArrayOf(318f, 292f, 326f, 296f, 322f, 286f)
        for (i in tx.indices) {
            val nx = if (i + 1 < tx.size) tx[i + 1] else -192f
            path.lineTo(tx[i] + bs * (0.6f + 0.1f * i), ty[i])
            path.lineTo((tx[i] + nx) / 2f, 215f)
        }
        path.close()
        p.shader = frontHairShader; p.style = Paint.Style.FILL; p.color = Color.WHITE
        c.drawPath(path, p)
        p.shader = null
        stroke(Color.argb(80, 255, 255, 255), 14f)
        path.reset(); path.moveTo(-120f, 92f); path.quadTo(0f, 55f, 120f, 92f)
        c.drawPath(path, p)

        // side locks
        val sl = sway * 10f
        p.shader = frontHairShader; p.style = Paint.Style.FILL; p.color = Color.WHITE
        path.reset()
        path.moveTo(-175f, 250f); path.quadTo(-232f + sl, 420f, -205f + sl * 1.5f, 660f)
        path.quadTo(-172f, 460f, -140f, 310f); path.close()
        c.drawPath(path, p)
        path.reset()
        path.moveTo(175f, 250f); path.quadTo(232f + sl, 420f, 205f + sl * 1.5f, 660f)
        path.quadTo(172f, 460f, 140f, 310f); path.close()
        c.drawPath(path, p)
        p.shader = null

        // hair bow
        val bw = sway * 6f
        fill(orange)
        path.reset()
        path.moveTo(-140f, 120f); path.quadTo(-215f, 70f + bw, -225f, 130f)
        path.quadTo(-195f, 175f, -140f, 120f); path.close(); c.drawPath(path, p)
        path.reset()
        path.moveTo(-140f, 120f); path.quadTo(-90f, 60f + bw, -70f, 115f)
        path.quadTo(-95f, 170f, -140f, 120f); path.close(); c.drawPath(path, p)
        fill(Color.rgb(230, 90, 40)); c.drawCircle(-140f, 120f, 15f, p)

        // ahoge
        stroke(Color.rgb(255, 150, 200), 12f)
        val wag = sin(time * 2.4f)
        path.reset()
        path.moveTo(0f, 55f)
        path.quadTo(32f + wag * 10f, -30f, 10f + wag * 24f, -62f)
        c.drawPath(path, p)

        c.restore()
    }

    // ---------------- fx & bubble ----------------

    private fun drawFx(c: Canvas) {
        for (f in fx) {
            val a = (255 * (f.life / f.maxLife).coerceIn(0f, 1f)).toInt()
            if (f.type == 0) {
                fill(Color.argb(a, 255, 105, 160))
                val s = f.size
                path.reset()
                path.moveTo(f.x, f.y + s)
                path.cubicTo(f.x - 1.6f * s, f.y - 0.2f * s, f.x - 0.8f * s, f.y - 1.4f * s, f.x, f.y - 0.5f * s)
                path.cubicTo(f.x + 0.8f * s, f.y - 1.4f * s, f.x + 1.6f * s, f.y - 0.2f * s, f.x, f.y + s)
                path.close()
                c.drawPath(path, p)
            } else {
                fill(Color.argb(a, 255, 250, 200))
                val s = f.size * (0.7f + 0.3f * sin(time * 8f + f.x))
                path.reset()
                path.moveTo(f.x, f.y - s)
                path.quadTo(f.x, f.y, f.x + s, f.y)
                path.quadTo(f.x, f.y, f.x, f.y + s)
                path.quadTo(f.x, f.y, f.x - s, f.y)
                path.quadTo(f.x, f.y, f.x, f.y - s)
                path.close()
                c.drawPath(path, p)
            }
        }
    }

    private fun wrap(text: String, maxW: Float): List<String> {
        val lines = ArrayList<String>()
        var cur = ""
        for (word in text.split(" ")) {
            val t = if (cur.isEmpty()) word else "$cur $word"
            if (cur.isEmpty() || tp.measureText(t) <= maxW) cur = t
            else { lines.add(cur); cur = word }
        }
        if (cur.isNotEmpty()) lines.add(cur)
        return lines
    }

    private fun drawBubble(c: Canvas, w: Float) {
        val now = System.currentTimeMillis()
        val text = MayaBus.bubble
        if (text.isBlank() || now > MayaBus.bubbleUntil) return
        if (MayaBus.bubbleUntil != shownUntil) { shownUntil = MayaBus.bubbleUntil; bubbleAt = time }
        val pop = easeOutBack(((time - bubbleAt) / 0.25f).coerceIn(0f, 1f))
        val fade = ((MayaBus.bubbleUntil - now) / 300f).coerceIn(0f, 1f)

        tp.textSize = w * 0.043f
        tp.typeface = bubbleFont
        val lines = wrap(text, w * 0.74f)
        val lh = tp.textSize * 1.3f
        var tw = 0f
        for (l in lines) tw = max(tw, tp.measureText(l))
        val padX = tp.textSize * 0.9f
        val padY = tp.textSize * 0.65f
        val bw = tw + padX * 2f
        val bh = lines.size * lh + padY * 2f
        val cx = w / 2f
        val tipY = oy + 30f * sc
        val bottom = tipY - tp.textSize * 0.8f
        val top = bottom - bh

        c.save()
        c.scale(pop, pop, cx, tipY)
        fill(Color.argb((245 * fade).toInt(), 255, 255, 255))
        rect.set(cx - bw / 2f, top, cx + bw / 2f, bottom)
        c.drawRoundRect(rect, bh * 0.35f, bh * 0.35f, p)
        path.reset()
        path.moveTo(cx - 18f, bottom - 2f); path.lineTo(cx + 18f, bottom - 2f); path.lineTo(cx, tipY)
        path.close(); c.drawPath(path, p)
        stroke(Color.argb((200 * fade).toInt(), 255, 120, 190), 3f)
        c.drawRoundRect(rect, bh * 0.35f, bh * 0.35f, p)
        tp.style = Paint.Style.FILL
        tp.color = Color.argb((255 * fade).toInt(), 80, 30, 100)
        tp.textAlign = Paint.Align.CENTER
        var y = top + padY + tp.textSize * 0.95f
        for (l in lines) { c.drawText(l, cx, y, tp); y += lh }
        c.restore()
    }
}
