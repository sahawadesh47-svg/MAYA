package com.maya.assistant

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.provider.Settings
import android.provider.MediaStore
import android.provider.AlarmClock
import android.view.KeyEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MayaService : Service(), TextToSpeech.OnInitListener {

    private enum class S { WAKE, COMMAND, CALL_NAME, MSG_NAME, MSG_TEXT, CONFIRM, PLAY_NAME }

    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private val handler = Handler(Looper.getMainLooper())
    private var state = S.WAKE
    private var speaking = false
    private var triggered = false
    private var retries = 0
    private var speakId = 0

    private var pendingName = ""
    private var pendingNumber = ""
    private var pendingText = ""
    private var pendingAction: (() -> Unit)? = null
    private var torchOn = false

    override fun onBind(intent: Intent?): IBinder? = null

    private fun toast(msg: String) =
        handler.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show() }

    override fun onCreate() {
        super.onCreate()
        val ch = "maya"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Maya", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("Maya sun rahi hai")
            .setContentText("Bolo: Maya")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(1, n)
        MayaBus.running = true
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("Google app install/update karo, speech service nahi mili")
        }
        tts = TextToSpeech(this, this)
        try {
            getSystemService(CameraManager::class.java).registerTorchCallback(
                object : CameraManager.TorchCallback() {
                    override fun onTorchModeChanged(cameraId: String, enabled: Boolean) { torchOn = enabled }
                }, handler)
        } catch (e: Exception) {}
        handler.postDelayed({ startListening() }, 800)
    }

    override fun onInit(status: Int) {
        val r = tts.setLanguage(Locale("hi", "IN"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(Locale("en", "IN"))
        }
        tts.setPitch(1.3f)        // pyaari awaaz (1.0 = normal)
        tts.setSpeechRate(1.0f)   // normal speed
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) { finishSpeaking() }
            override fun onDone(id: String?) { finishSpeaking() }
        })
    }

    private fun finishSpeaking() {
        handler.post {
            if (speaking) {
                speaking = false
                MayaBus.speaking = false
                MayaBus.bubbleUntil = System.currentTimeMillis() + 1200
                startListening()
            }
        }
    }

    private fun speak(text: String) {
        MayaBus.setBubble(text, 4000)
        MayaBus.speaking = true
        speaking = true
        recognizer?.cancel()
        val myId = ++speakId
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "maya_utt")
        handler.postDelayed({ if (speaking && speakId == myId) finishSpeaking() }, 9000)
    }

    private fun startListening() {
        if (speaking) return
        triggered = false
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    if (triggered) return
                    val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val raw = list?.firstOrNull() ?: ""
                    val all = list?.joinToString(" ")?.lowercase() ?: ""
                    toast("Suna: $raw")
                    retries = 0
                    handleSpeech(raw, if (state == S.WAKE) all else raw.lowercase())
                }

                override fun onPartialResults(partial: Bundle?) {
                    if (state != S.WAKE || triggered) return
                    val text = partial?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.joinToString(" ")?.lowercase() ?: ""
                    if (isWakeWord(text)) {
                        triggered = true
                        toast("Suna: $text")
                        state = S.COMMAND
                        MayaBus.wakeCount++; speak("Ha jaanu")
                    }
                }

                override fun onError(error: Int) {
                    if (triggered || speaking) return
                    val quiet = error == SpeechRecognizer.ERROR_NO_MATCH ||
                        error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                    if (!quiet) toast("Mic error code: $error")
                    if (state != S.WAKE && quiet && retries < 2) retries++
                    else { state = S.WAKE; retries = 0 }
                    val delay = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200L else 300L
                    handler.postDelayed({ startListening() }, delay)
                }

                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        recognizer?.startListening(i)
    }

    private fun lev(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length)
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1,
                d[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        return d[a.length][b.length]
    }

    private fun isWakeWord(text: String): Boolean {
        val extra = listOf("my", "mia", "miya", "maiya", "maaya", "mayaa", "meya", "माया", "मया", "मैया", "मायां")
        return text.split(" ", ",", ".").filter { it.isNotBlank() }.any { w ->
            w in extra || lev(w, "maya") <= 1 || w.contains("maya")
        }
    }

    // ---------- Dialog / state machine ----------

    private fun handleSpeech(raw: String, t: String) {
        when (state) {
            S.WAKE -> {
                if (isWakeWord(t)) { triggered = true; state = S.COMMAND; MayaBus.wakeCount++; speak("Ha jaanu") }
                else startListening()
            }
            S.COMMAND -> handleCommand(t)
            S.CALL_NAME -> prepareCall(cleanName(t))
            S.MSG_NAME -> prepareMessageName(cleanName(t))
            S.PLAY_NAME -> { state = S.WAKE; playMusic(raw.trim()) }
            S.MSG_TEXT -> {
                pendingText = raw.trim()
                val text = pendingText
                val name = pendingName
                val number = pendingNumber
                state = S.CONFIRM
                pendingAction = { sendWhatsApp(number, text) }
                speak("$name ko $text bhej du? Haan ya nahi bolo")
            }
            S.CONFIRM -> {
                val words = t.split(" ", ",", ".").filter { it.isNotBlank() }
                val no = words.any { it in listOf("nahi", "nahin", "nahee", "nai", "no", "nope", "mat", "cancel", "ruko", "नहीं") }
                val yes = words.any { it in listOf("haan", "han", "haa", "ha", "hanji", "haanji", "ji", "yes", "yeah", "yep", "yup", "ok", "okay", "theek", "thik", "sahi", "bilkul", "sure", "bhej", "send", "kar", "karo", "हाँ", "हां") }
                state = S.WAKE
                if (yes && !no) { val a = pendingAction; pendingAction = null; a?.invoke() }
                else { pendingAction = null; speak("Ok janu, nahi kiya") }
            }
        }
    }

    private fun cleanName(t: String): String =
        t.replace(Regex("\\b(call|dial|karo|kar do|kardo|lagao|laga do|phone|ko|to|whatsapp|message|msg|massage|send|bhejo|bhej do|bhej|par|pe|on|a|the|please|maya|mujhe|ek)\\b"), " ")
            .replace(Regex("\\s+"), " ").trim()

    private fun handleCommand(t: String) {
        when {
            tryFavourite(t) -> {}
            !hasOpen(t) && (t.contains("call") || t.contains("dial") || t.contains("phone laga")) -> {
                val name = cleanName(t)
                if (name.isBlank()) { state = S.CALL_NAME; speak("Kisko call karu janu?") }
                else prepareCall(name)
            }
            !hasOpen(t) && (t.contains("message") || t.contains("msg") || t.contains("massage") || t.contains("bhejo") || t.contains("send")) -> {
                val name = cleanName(t)
                if (name.isBlank()) { state = S.MSG_NAME; speak("Kisko message bhejna hai janu?") }
                else prepareMessageName(name)
            }
            isPlay(t) -> playFromCommand(t)
            tryDevice(t) -> {}
            tokens(t).any { it in listOf("chalao", "chala", "chalado") } && !hasOpen(t) -> playFromCommand(t)
            t.contains("open") || t.contains("kholo") || t.contains("khol") || t.contains("ओपन") -> {
                state = S.WAKE
                val name = t.replace(Regex("\\b(open|kholo|khol|karo|kar do|kardo|app|ko|maya|please)\\b|ओपन"), " ").replace(Regex("\\s+"), " ").trim()
                val pkg = findPackage(name)
                if (pkg != null) {
                    speak("Mai $name open kar rahi hu janu")
                    handler.postDelayed({
                        packageManager.getLaunchIntentForPackage(pkg)?.let {
                            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            launch(it)
                        }
                    }, 1800)
                } else speak("Janu mujhe $name app nahi mila")
            }
            t.contains("home") -> { state = S.WAKE; speak("Ok janu"); MayaAccessibilityService.home() }
            t.contains("back") || t.contains("peeche") -> { state = S.WAKE; speak("Ok janu"); MayaAccessibilityService.back() }
            else -> { state = S.WAKE; speak("Janu mai samjhi nahi") }
        }
    }

    private fun hasOpen(t: String): Boolean =
        tokens(t).any { it in listOf("open", "kholo", "khol", "kholna") } || t.contains("ओपन")

    private fun launch(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val ctx: android.content.Context = MayaAccessibilityService.instance ?: this
        ctx.startActivity(i)
    }

    // ---------- Call ----------

    private fun prepareCall(name: String) {
        val c = findContact(name)
        if (c == null) {
            state = S.WAKE
            speak("Janu $name naam ka contact nahi mila, ya contacts permission nahi hai")
            return
        }
        val (dispName, number) = c
        state = S.CONFIRM
        pendingAction = { doCall(dispName, number) }
        speak("$dispName ko call lagau? Haan ya nahi bolo")
    }

    private fun doCall(name: String, number: String) {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            speak("Janu call ki permission do"); return
        }
        speak("Mai $name ko call kar rahi hu janu")
        handler.postDelayed({
            val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number)))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            launch(i)
        }, 1800)
    }

    // ---------- WhatsApp ----------

    private fun prepareMessageName(name: String) {
        val c = findContact(name)
        if (c == null) {
            state = S.WAKE
            speak("Janu $name naam ka contact nahi mila, ya contacts permission nahi hai")
            return
        }
        pendingName = c.first
        pendingNumber = c.second
        state = S.MSG_TEXT
        speak("${c.first} ko kya likhu janu?")
    }

    private fun sendWhatsApp(number: String, text: String) {
        var d = number.filter { it.isDigit() }
        if (d.length == 11 && d.startsWith("0")) d = d.substring(1)
        if (d.length == 10) d = "91$d"
        speak("Message bhej rahi hu janu")
        handler.postDelayed({
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$d?text=" + Uri.encode(text)))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            i.setPackage("com.whatsapp")
            try { launch(i) } catch (e: Exception) {
                i.setPackage(null); try { launch(i) } catch (e2: Exception) { toast("WhatsApp nahi mila") }
            }
            handler.postDelayed({
                MayaAccessibilityService.clickSend { ok ->
                    if (!ok) toast("Send button nahi mila, khud dabao")
                }
            }, 3500)
        }, 1800)
    }

    // ---------- Naye features ----------

    private val prefs by lazy { getSharedPreferences("maya_memory", MODE_PRIVATE) }

    private fun tokens(t: String) =
        t.replace("-", "").split(Regex("[^\\p{L}]+")).filter { it.isNotBlank() }

    private fun stripEdges(t: String, lead: Set<String>, trail: Set<String>): String {
        val w = t.split(Regex("\\s+")).filter { it.isNotBlank() }.toMutableList()
        while (w.isNotEmpty() && w.first() in lead) w.removeAt(0)
        while (w.isNotEmpty() && w.last() in trail) w.removeAt(w.size - 1)
        return w.joinToString(" ")
    }

    private fun normType(x: String) = when (x) {
        "song", "songs", "gaana", "gana", "music", "gane" -> "song"
        "game", "games" -> "game"
        "app", "apps", "application" -> "app"
        "movie", "movies", "film", "films", "picture" -> "movie"
        "person", "friend", "dost", "insan" -> "person"
        else -> x
    }

    private fun tryFavourite(t: String): Boolean {
        val m = Regex("favou?rite\\s+([a-z]+)\\s*(.*)").find(t) ?: return false
        val type = normType(m.groupValues[1])
        val actions = setOf("chalao", "chala", "play", "bajao", "baja", "kholo", "khol", "open", "call",
            "message", "msg", "kya", "batao", "bata", "what", "who", "kaun", "kaunsa", "sunao", "dikhao")
        val questions = setOf("kya", "what", "who", "kaun", "kaunsa", "which")
        val markers = setOf("hai", "is", "save", "yaad", "remember", "h", "he")
        val leadF = setOf("hai", "is", "ye", "yeh", "this", "mera", "meri", "my", "he", "h", "hain", "maya")
        val trailF = setOf("hai", "hain", "h", "is", "he", "save", "kar", "karo", "lo", "le", "yaad",
            "rakho", "rakh", "ok", "okay", "it", "isko", "remember", "do", "krlo", "kro")
        val before = stripEdges(t.substring(0, m.range.first).trim(), leadF,
            trailF + setOf("mera", "meri", "my", "ye", "yeh", "this"))
        val rest = m.groupValues[2].trim()
        val restWords = rest.split(Regex("\\s+")).filter { it.isNotBlank() }
        val action = restWords.firstOrNull { it in actions }
        val hasQ = restWords.any { it in questions }
        val hasMarker = restWords.any { it in markers }
        state = S.WAKE

        if (!hasQ && (action == null || hasMarker)) {
            val restClean = stripEdges(rest, leadF, trailF)
            val value = if (restClean.isNotBlank()) restClean else before
            if (value.isNotBlank()) {
                prefs.edit().putString("fav_$type", value).apply()
                speak("Ok janu, aapka favourite $type $value maine yaad kar liya")
                return true
            }
        }

        val value = prefs.getString("fav_$type", null)
        if (value == null) {
            speak("Janu aapne favourite $type abhi nahi bataya. Bolo, mera favourite $type kya hai")
            return true
        }
        val a = action ?: ""
        when {
            a in questions || a == "batao" || a == "bata" -> speak("Aapka favourite $type $value hai janu")
            a == "call" -> prepareCall(value)
            a == "message" || a == "msg" -> prepareMessageName(value)
            type == "song" -> playMusic(value)
            type == "movie" -> playVideo(value)
            type == "game" || type == "app" -> openApp(value)
            else -> speak("Aapka favourite $type $value hai janu")
        }
        return true
    }

    private fun openApp(name: String) {
        state = S.WAKE
        val pkg = findPackage(name)
        if (pkg != null) {
            speak("Mai $name open kar rahi hu janu")
            handler.postDelayed({
                packageManager.getLaunchIntentForPackage(pkg)?.let {
                    it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    launch(it)
                }
            }, 1800)
        } else speak("Janu mujhe $name app nahi mila")
    }

    private fun isPlay(t: String): Boolean {
        val w = tokens(t)
        val block = listOf("volume", "awaz", "awaaz", "brightness", "pause", "next", "previous",
            "resume", "agla", "pichla", "store", "alarm", "timer", "open", "kholo", "khol")
        if (w.any { it in block }) return false
        return w.firstOrNull { it != "maya" } == "play" ||
            w.any { it in listOf("song", "songs", "gaana", "gana", "music", "bajao", "baja") }
    }

    private fun playFromCommand(t: String) {
        val q = stripEdges(t,
            setOf("play", "song", "songs", "gaana", "gana", "music", "maya", "please", "ek", "mera", "ye"),
            setOf("play", "chalao", "chala", "chalado", "do", "kar", "karo", "song", "songs", "gaana",
                "gana", "music", "bajao", "baja", "please", "youtube", "pe", "par", "on", "dena", "de"))
        if (q.isBlank()) { state = S.PLAY_NAME; speak("Kaun sa gaana chalau janu?") }
        else playMusic(q)
    }

    private fun youtubeSearch(query: String) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        i.setPackage("com.google.android.youtube")
        try { launch(i) } catch (e: Exception) {
            i.setPackage(null)
            try { launch(i) } catch (e2: Exception) { toast("YouTube nahi mila") }
        }
        handler.postDelayed({
            MayaAccessibilityService.clickFirstVideo { ok -> if (!ok) toast("Video khud chuno") }
        }, 4000)
    }

    private fun playVideo(query: String) {
        state = S.WAKE
        speak("Mai $query chala rahi hu janu")
        handler.postDelayed({ youtubeSearch(query) }, 1800)
    }

    private fun playMusic(query: String) {
        state = S.WAKE
        speak("Mai $query chala rahi hu janu")
        handler.postDelayed({
            for (pkg in listOf("com.google.android.apps.youtube.music", "com.spotify.music")) {
                if (packageManager.getLaunchIntentForPackage(pkg) == null) continue
                try {
                    val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                        .setPackage(pkg)
                        .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                        .putExtra(SearchManager.QUERY, query)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    launch(i)
                    return@postDelayed
                } catch (e: Exception) {}
            }
            youtubeSearch(query)
        }, 1800)
    }

    private fun mediaKey(code: Int) {
        val am = getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun doBrightness(w: List<String>, num: Int?) {
        if (!Settings.System.canWrite(this)) {
            speak("Janu brightness ki permission do, Settings khol rahi hu")
            handler.postDelayed({
                try {
                    launch(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {}
            }, 1800)
            return
        }
        val cr = contentResolver
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        val cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
        val v = when {
            num != null -> num.coerceIn(0, 100) * 255 / 100
            w.any { it in listOf("full", "max", "maximum") } -> 255
            w.any { it in listOf("low", "min", "minimum") } -> 20
            w.any { it in listOf("kam", "down", "ghata", "ghatao", "decrease", "lower", "dim") } -> cur - 60
            else -> cur + 60
        }.coerceIn(10, 255)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, v)
        speak("Ok janu, brightness ${v * 100 / 255} percent")
    }

    private fun setAlarm(t2: String, w: List<String>): Boolean {
        state = S.WAKE
        val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?").find(t2)
        if (m == null) { speak("Janu kitne baje ka alarm lagau? Bolo jaise alarm 7 baje"); return true }
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].toIntOrNull() ?: 0
        if (w.any { it in listOf("pm", "shaam", "raat", "dopahar") } && h < 12) h += 12
        if (w.contains("am") && h == 12) h = 0
        if (h > 23 || min > 59) { speak("Janu samay samjha nahi"); return true }
        speak("Ok janu, $h ${min.toString().padStart(2, '0')} ka alarm laga rahi hu")
        handler.postDelayed({
            val i = Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, min)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Maya")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { launch(i) } catch (e: Exception) { toast("Alarm app nahi mila") }
        }, 1800)
        return true
    }

    private fun setTimer(t2: String): Boolean {
        state = S.WAKE
        val m = Regex("(\\d+)\\s*(second|sec|minute|min|mint|hour|ghanta|ghante)?").find(t2)
        if (m == null) { speak("Janu kitne minute ka timer lagau?"); return true }
        val n = m.groupValues[1].toInt()
        val u = m.groupValues[2]
        val secs = when {
            u.startsWith("sec") -> n
            u.startsWith("hour") || u.startsWith("ghant") -> n * 3600
            else -> n * 60
        }
        speak("Ok janu, timer laga rahi hu")
        handler.postDelayed({
            val i = Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, secs)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Maya")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { launch(i) } catch (e: Exception) { toast("Clock app nahi mila") }
        }, 1800)
        return true
    }

    private fun doTap(t: String): Boolean {
        state = S.WAKE
        val name = stripEdges(t.replace("-", " "),
            setOf("click", "tap", "press", "on", "maya", "please"),
            setOf("click", "tap", "press", "dabao", "karo", "kar", "do", "par", "pe", "on", "button", "please"))
        if (name.isBlank()) { speak("Janu kispe dabau?"); return true }
        val ok = MayaAccessibilityService.clickText(name)
        speak(if (ok) "Ok janu, $name dabaya" else "Janu mujhe $name screen pe nahi dikha")
        return true
    }

    private fun doType(t: String): Boolean {
        state = S.WAKE
        val m = Regex("(?:type|likho)\\s+(.*)").find(t)
        var text = m?.groupValues?.get(1)?.trim() ?: ""
        if (text.isBlank()) text = stripEdges(t, setOf("maya"), setOf("likho", "type", "karo", "kar", "do"))
        if (text.isBlank()) { speak("Janu kya likhu?"); return true }
        val ok = MayaAccessibilityService.typeText(text)
        speak(if (ok) "Ok janu, likh diya" else "Janu likhne ki jagah nahi mili, pehle box pe tap karo")
        return true
    }

    // ---------- Phone controls ----------

    private fun wantOf(w: List<String>): Boolean? {
        val off = listOf("off", "band", "bandh", "stop", "disable", "bujha", "bujhao", "बंद")
        val on = listOf("on", "chalu", "start", "enable", "jala", "jalao", "चालू")
        return when {
            w.any { it in off } -> false
            w.any { it in on } -> true
            else -> null
        }
    }

    private fun setTorch(on: Boolean?): Boolean {
        return try {
            val cm = getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false
            cm.setTorchMode(id, on ?: !torchOn)
            true
        } catch (e: Exception) { false }
    }

    private fun doVolume(w: List<String>, num: Int?) {
        val am = getSystemService(AudioManager::class.java)
        val s = AudioManager.STREAM_MUSIC
        val max = am.getStreamMaxVolume(s)
        when {
            num != null -> am.setStreamVolume(s, num.coerceIn(0, 100) * max / 100, AudioManager.FLAG_SHOW_UI)
            w.any { it in listOf("mute", "zero", "band", "bandh") } -> am.setStreamVolume(s, 0, AudioManager.FLAG_SHOW_UI)
            w.any { it in listOf("full", "max", "maximum") } -> am.setStreamVolume(s, max, AudioManager.FLAG_SHOW_UI)
            w.any { it in listOf("kam", "down", "ghata", "ghatao", "decrease", "low", "lower") } ->
                repeat(3) { am.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, if (it == 2) AudioManager.FLAG_SHOW_UI else 0) }
            else ->
                repeat(3) { am.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, if (it == 2) AudioManager.FLAG_SHOW_UI else 0) }
        }
    }

    private fun tryDevice(t: String): Boolean {
        val t2 = t.replace("-", "")
        val w = t2.split(Regex("[^\\p{L}]+")).filter { it.isNotBlank() }
        fun has(vararg k: String) = w.any { it in k }
        val want = wantOf(w)
        val num = Regex("\\d+").find(t2)?.value?.toIntOrNull()
        val onoff = when (want) { true -> "on"; false -> "off"; null -> "on off" }

        fun qs(name: String, labels: List<String>, stage2: String?, fb: Intent?): Boolean {
            state = S.WAKE
            speak("Mai $name $onoff kar rahi hu janu")
            handler.postDelayed({
                MayaAccessibilityService.quickToggle(labels, want, stage2, fb) { r ->
                    if (r == "fallback") toast("Settings khol di, khud dabao")
                    if (r == "noaccess") toast("Accessibility ON karo")
                }
            }, 1500)
            return true
        }

        fun act(msg: String, f: () -> Unit): Boolean {
            state = S.WAKE
            speak(msg)
            handler.postDelayed({ f() }, 1800)
            return true
        }

        return when {
            has("volume", "awaz", "awaaz", "sound") -> { state = S.WAKE; doVolume(w, num); speak("Ok janu"); true }
            w.any { it.startsWith("torch") || it.startsWith("flash") || it == "tourch" || it == "tarch" || it == "batti" } -> {
                state = S.WAKE
                val ok = setTorch(want)
                speak(if (ok) "Mai torch $onoff kar rahi hu janu" else "Janu is phone me torch nahi mila")
                true
            }
            t2.contains("hotspot") || t2.contains("hot spot") ->
                qs("hotspot", listOf("hotspot", "tethering"), null,
                    Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"))
            t2.contains("wifi") || t2.contains("wi fi") ->
                qs("wifi", listOf("wifi", "internet"), "wifi", Intent(Settings.ACTION_WIFI_SETTINGS))
            t2.contains("bluetooth") || t2.contains("blue tooth") ->
                qs("bluetooth", listOf("bluetooth"), null, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            has("data") ->
                qs("mobile data", listOf("mobile data", "cellular data", "internet"), "mobile data",
                    Intent(Settings.ACTION_DATA_ROAMING_SETTINGS))
            t2.contains("airplane") || t2.contains("flight mode") ->
                qs("airplane mode", listOf("airplane", "flight mode"), null, Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
            t2.contains("rotat") ->
                qs("auto rotate", listOf("autorotate", "auto rotate", "rotation"), null, Intent(Settings.ACTION_DISPLAY_SETTINGS))
            has("location", "gps") ->
                qs("location", listOf("location"), null, Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            t2.contains("disturb") || has("dnd", "silent") ->
                qs("do not disturb", listOf("do not disturb", "dnd", "silent"), null, Intent("android.settings.ZEN_MODE_SETTINGS"))
            t2.contains("battery saver") || t2.contains("power saving") ->
                qs("battery saver", listOf("battery saver", "power saving"), null, Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
            t2.contains("screenshot") || t2.contains("screen shot") ->
                act("Ok janu, screenshot le rahi hu") { MayaAccessibilityService.screenshot() }
            has("lock") && !has("unlock") ->
                act("Ok janu, phone lock kar rahi hu") { MayaAccessibilityService.lockScreen() }
            t2.contains("notification") ->
                act("Ok janu") { MayaAccessibilityService.notifications() }
            has("recent", "recents") ->
                act("Ok janu") { MayaAccessibilityService.recents() }
            has("scroll") -> {
                val down = !has("up", "upar")
                act("Ok janu") { MayaAccessibilityService.scroll(down) }
            }
            has("vibrate", "vibration") -> {
                try { getSystemService(AudioManager::class.java).ringerMode = AudioManager.RINGER_MODE_VIBRATE } catch (e: Exception) {}
                act("Ok janu, vibrate mode") {}
            }
            has("brightness", "brightnes", "roshni") -> { state = S.WAKE; doBrightness(w, num); true }
            has("pause", "roko") -> { state = S.WAKE; mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE); speak("Ok janu"); true }
            has("resume") -> { state = S.WAKE; mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY); speak("Ok janu"); true }
            has("next", "agla") -> { state = S.WAKE; mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT); speak("Ok janu"); true }
            has("previous", "pichla") -> { state = S.WAKE; mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS); speak("Ok janu"); true }
            has("alarm") -> setAlarm(t2, w)
            has("timer") -> setTimer(t2)
            has("time", "samay", "baje") -> {
                state = S.WAKE
                speak("Janu abhi " + SimpleDateFormat("h mm a", Locale.ENGLISH).format(Date()) + " baj rahe hain")
                true
            }
            has("battery") -> {
                state = S.WAKE
                val pct = getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                speak("Janu battery $pct percent hai")
                true
            }
            has("click", "tap", "dabao", "press") -> doTap(t)
            has("type", "likho") -> doType(t)
            else -> false
        }
    }

    // ---------- Helpers ----------

    private fun findContact(name: String): Pair<String, String>? {
        if (name.isBlank()) return null
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val dn = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        val num = ContactsContract.CommonDataKinds.Phone.NUMBER
        return try {
            var best: Pair<String, String>? = null
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(dn, num), "$dn LIKE ?", arrayOf("%$name%"), null
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0) ?: continue
                    val v = c.getString(1) ?: continue
                    val b = best
                    if (b == null || n.length < b.first.length) best = Pair(n, v)
                }
            }
            best
        } catch (e: Exception) { null }
    }

    private fun findPackage(name: String): String? {
        if (name.isBlank()) return null
        val q = name.lowercase().replace(" ", "")
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(i, 0).map {
            it.loadLabel(packageManager).toString().lowercase().replace(" ", "") to it.activityInfo.packageName
        }.filter { it.first.isNotEmpty() }
        return apps.firstOrNull { it.first == q }?.second
            ?: apps.filter { it.first.contains(q) }.minByOrNull { it.first.length }?.second
            ?: apps.firstOrNull { it.first.length >= 3 && q.contains(it.first) }?.second
    }

    override fun onDestroy() {
        MayaBus.running = false
        MayaBus.speaking = false
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}
