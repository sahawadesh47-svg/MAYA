package com.maya.assistant

import android.app.*
import android.content.Intent
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class MayaService : Service(), TextToSpeech.OnInitListener {

    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private val handler = Handler(Looper.getMainLooper())
    private var awaitingCommand = false
    private var speaking = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "maya"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Maya", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("Maya sun rahi hai")
            .setContentText("Bolo: Maya")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(1, n)
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        tts.language = Locale("hi", "IN")
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) { done() }
            override fun onDone(id: String?) { done() }
            private fun done() { speaking = false; handler.post { startListening() } }
        })
        startListening()
    }

    private fun speak(text: String) {
        speaking = true
        recognizer?.cancel()
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "maya_utt")
    }

    private fun startListening() {
        if (speaking) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()?.lowercase() ?: ""
                    handleSpeech(text)
                }
                override fun onError(error: Int) {
                    awaitingCommand = false.takeIf { error != SpeechRecognizer.ERROR_NO_MATCH && !awaitingCommand } ?: awaitingCommand
                    handler.postDelayed({ startListening() }, 400)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer?.startListening(i)
    }

    private fun handleSpeech(text: String) {
        if (!awaitingCommand) {
            if (text.contains("maya") || text.contains("maia") || text.contains("maya") || text.contains("माया")) {
                awaitingCommand = true
                speak("Ha jaanu")
            } else startListening()
            return
        }
        awaitingCommand = false
        handleCommand(text)
    }

    private fun handleCommand(t: String) {
        when {
            t.contains("open") || t.contains("kholo") || t.contains("khol") || t.contains("ओपन") -> {
                val name = t.replace(Regex("open|kholo|khol|karo|kar do|app|ko|ओपन"), "").trim()
                val pkg = findPackage(name)
                if (pkg != null) {
                    speak("Mai $name open kar rahi hu janu")
                    handler.postDelayed({
                        packageManager.getLaunchIntentForPackage(pkg)?.let {
                            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(it)
                        }
                    }, 1500)
                } else speak("Janu mujhe $name app nahi mila")
            }
            t.contains("home") -> { speak("Ok janu"); MayaAccessibilityService.home() }
            t.contains("back") || t.contains("peeche") -> { speak("Ok janu"); MayaAccessibilityService.back() }
            else -> speak("Janu mai samjhi nahi")
        }
    }

    private fun findPackage(name: String): String? {
        if (name.isBlank()) return null
        val q = name.replace(" ", "")
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(i, 0)
        return apps.firstOrNull {
            val l = it.loadLabel(packageManager).toString().lowercase().replace(" ", "")
            l == q || l.contains(q) || q.contains(l)
        }?.activityInfo?.packageName
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}
