package com.maya.assistant

/** Service aur screen ke beech chhota sa sandesh-bus. */
object MayaBus {
    @Volatile var running = false
    @Volatile var speaking = false
    @Volatile var activitySpeaking = false
    @Volatile var wakeCount = 0
    @Volatile var bubble = ""
    @Volatile var bubbleUntil = 0L

    fun setBubble(text: String, ms: Long = 3500) {
        bubble = text
        bubbleUntil = System.currentTimeMillis() + ms
    }
}
